
package com.example.civicfix.ai;

import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;

public class MyComplaintsActivity extends AppCompatActivity {

    private LinearLayout complaintsContainer;

    private final String[] statusOptions = {
            "Submitted",
            "In Progress",
            "Resolved"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 24);
        root.setBackgroundColor(Color.rgb(243, 246, 251));

        TextView heading = new TextView(this);
        heading.setText(R.string.my_complaints_heading);
        heading.setTextSize(26);
        heading.setTypeface(null, Typeface.BOLD);
        heading.setTextColor(Color.rgb(23, 54, 93));
        heading.setPadding(0, 0, 0, 24);
        root.addView(heading);

        android.widget.ScrollView scrollView =
                new android.widget.ScrollView(this);

        complaintsContainer = new LinearLayout(this);
        complaintsContainer.setOrientation(LinearLayout.VERTICAL);

        scrollView.addView(complaintsContainer);

        root.addView(scrollView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1
        ));

        setContentView(root);
        displayComplaints();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (complaintsContainer != null) {
            displayComplaints();
        }
    }

    private void displayComplaints() {
        complaintsContainer.removeAllViews();

        SharedPreferences preferences = getSharedPreferences(
                "CivicFixComplaints", MODE_PRIVATE);

        String savedData = preferences.getString("complaints", "[]");

        try {
            JSONArray complaints = new JSONArray(savedData);

            if (complaints.length() == 0) {
                TextView emptyMessage = new TextView(this);
                emptyMessage.setText(R.string.no_complaints_message);
                emptyMessage.setTextSize(16);
                emptyMessage.setTextColor(Color.DKGRAY);
                complaintsContainer.addView(emptyMessage);
                return;
            }

            for (int i = complaints.length() - 1; i >= 0; i--) {
                final int complaintIndex = i;

                JSONObject complaint = complaints.getJSONObject(i);

                String title = complaint.optString("title", "Untitled");
                String description = complaint.optString("description", "");
                String category = complaint.optString("category", "");
                String location = complaint.optString("location", "");
                String status = complaint.optString("status", "Submitted");
                String imagePath = complaint.optString("imagePath", "");

                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(20, 20, 20, 20);
                card.setBackgroundColor(Color.WHITE);

                LinearLayout.LayoutParams cardParams =
                        new LinearLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT);

                cardParams.setMargins(0, 0, 0, 16);

                TextView titleView = new TextView(this);
                titleView.setText(title);
                titleView.setTextSize(20);
                titleView.setTypeface(null, Typeface.BOLD);
                titleView.setTextColor(Color.rgb(23, 54, 93));
                card.addView(titleView);

                if (!imagePath.isEmpty()) {
                    File photoFile = new File(imagePath);

                    if (photoFile.exists()) {
                        Bitmap bitmap = BitmapFactory.decodeFile(imagePath);

                        if (bitmap != null) {
                            ImageView photoView = new ImageView(this);

                            LinearLayout.LayoutParams photoParams =
                                    new LinearLayout.LayoutParams(
                                            ViewGroup.LayoutParams.MATCH_PARENT,
                                            450
                                    );

                            photoParams.setMargins(0, 16, 0, 8);

                            photoView.setLayoutParams(photoParams);
                            photoView.setScaleType(
                                    ImageView.ScaleType.CENTER_CROP);
                            photoView.setContentDescription(
                                    getString(R.string.complaint_photo_description));
                            photoView.setImageBitmap(bitmap);

                            card.addView(photoView);
                        }
                    }
                }

                addDetail(card, "Description: " + description);
                addDetail(card, "Category: " + category);
                addDetail(card, "Location: " + location);

                TextView statusLabel = new TextView(this);
                statusLabel.setText("Update Status:");
                statusLabel.setTextSize(15);
                statusLabel.setTypeface(null, Typeface.BOLD);
                statusLabel.setTextColor(Color.DKGRAY);
                statusLabel.setPadding(0, 14, 0, 4);
                card.addView(statusLabel);

                Spinner statusSpinner = new Spinner(this);

                ArrayAdapter<String> adapter = new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        statusOptions
                );

                adapter.setDropDownViewResource(
                        android.R.layout.simple_spinner_dropdown_item);

                statusSpinner.setAdapter(adapter);

                int selectedPosition = 0;

                for (int j = 0; j < statusOptions.length; j++) {
                    if (statusOptions[j].equals(status)) {
                        selectedPosition = j;
                        break;
                    }
                }

                statusSpinner.setSelection(selectedPosition);
                card.addView(statusSpinner);

                boolean[] initialSelectionHandled = {false};

                statusSpinner.setOnItemSelectedListener(
                        new AdapterView.OnItemSelectedListener() {

                            @Override
                            public void onItemSelected(
                                    AdapterView<?> parent,
                                    android.view.View view,
                                    int position,
                                    long id) {

                                if (!initialSelectionHandled[0]) {
                                    initialSelectionHandled[0] = true;
                                    return;
                                }

                                String newStatus = statusOptions[position];

                                try {
                                    SharedPreferences prefs = getSharedPreferences(
                                            "CivicFixComplaints", MODE_PRIVATE);

                                    JSONArray latestComplaints = new JSONArray(
                                            prefs.getString("complaints", "[]"));

                                    if (complaintIndex < latestComplaints.length()) {
                                        JSONObject updatedComplaint =
                                                latestComplaints.getJSONObject(
                                                        complaintIndex);

                                        updatedComplaint.put("status", newStatus);

                                        prefs.edit()
                                                .putString(
                                                        "complaints",
                                                        latestComplaints.toString())
                                                .apply();

                                        Toast.makeText(
                                                MyComplaintsActivity.this,
                                                "Status updated: " + newStatus,
                                                Toast.LENGTH_SHORT
                                        ).show();
                                    }

                                } catch (Exception e) {
                                    Toast.makeText(
                                            MyComplaintsActivity.this,
                                            "Unable to update status",
                                            Toast.LENGTH_SHORT
                                    ).show();
                                }
                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> parent) {
                            }
                        });

                complaintsContainer.addView(card, cardParams);
            }

        } catch (Exception e) {
            TextView error = new TextView(this);
            error.setText(R.string.unable_to_load_complaints);
            error.setTextColor(Color.RED);
            complaintsContainer.addView(error);
        }
    }

    private void addDetail(LinearLayout card, String text) {
        TextView detail = new TextView(this);
        detail.setText(text);
        detail.setTextSize(15);
        detail.setTextColor(Color.DKGRAY);
        detail.setPadding(0, 10, 0, 0);
        card.addView(detail);
    }
}
