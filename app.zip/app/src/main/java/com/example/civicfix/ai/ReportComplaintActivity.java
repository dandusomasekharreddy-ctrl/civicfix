package com.example.civicfix.ai;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

public class ReportComplaintActivity extends AppCompatActivity {

    private EditText etTitle, etDescription, etCategory, etLocation;
    private Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_complaint);

        etTitle = findViewById(R.id.etComplaintTitle);
        etDescription = findViewById(R.id.etComplaintDescription);
        etCategory = findViewById(R.id.etComplaintCategory);
        etLocation = findViewById(R.id.etComplaintLocation);
        btnSubmit = findViewById(R.id.btnSubmitComplaint);

        btnSubmit.setOnClickListener(v -> saveComplaint());
    }

    private void saveComplaint() {
        String title = etTitle.getText().toString().trim();
        String description = etDescription.getText().toString().trim();
        String category = etCategory.getText().toString().trim();
        String location = etLocation.getText().toString().trim();

        if (title.isEmpty() || description.isEmpty()) {
            Toast.makeText(this,
                    "Enter complaint title and description",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            SharedPreferences prefs =
                    getSharedPreferences("CivicFixComplaints", MODE_PRIVATE);

            JSONArray complaints = new JSONArray(
                    prefs.getString("complaints", "[]"));

            JSONObject complaint = new JSONObject();
            complaint.put("title", title);
            complaint.put("description", description);
            complaint.put("category", category);
            complaint.put("location", location);
            complaint.put("status", "Submitted");

            complaints.put(complaint);

            prefs.edit()
                    .putString("complaints", complaints.toString())
                    .apply();

            Toast.makeText(this,
                    "Complaint submitted successfully!",
                    Toast.LENGTH_LONG).show();

            finish();

        } catch (Exception e) {
            Toast.makeText(this,
                    "Error saving complaint",
                    Toast.LENGTH_SHORT).show();
        }
    }
}