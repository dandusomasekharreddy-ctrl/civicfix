
package com.example.civicfix.ai;

import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

public class TrackComplaintActivity extends AppCompatActivity {

    private EditText etSearch;
    private LinearLayout resultContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 24);
        root.setBackgroundColor(Color.rgb(243, 246, 251));

        TextView heading = new TextView(this);
        heading.setText("Track a Complaint");
        heading.setTextSize(26);
        heading.setTypeface(null, Typeface.BOLD);
        heading.setTextColor(Color.rgb(23, 54, 93));
        root.addView(heading);

        TextView instruction = new TextView(this);
        instruction.setText("Enter the exact complaint title to search.");
        instruction.setTextSize(15);
        instruction.setTextColor(Color.DKGRAY);
        instruction.setPadding(0, 12, 0, 16);
        root.addView(instruction);

        etSearch = new EditText(this);
        etSearch.setHint("Complaint title");
        etSearch.setSingleLine(true);
        root.addView(etSearch);

        Button btnSearch = new Button(this);
        btnSearch.setText("Search Complaint");
        root.addView(btnSearch);

        ScrollView scrollView = new ScrollView(this);
        resultContainer = new LinearLayout(this);
        resultContainer.setOrientation(LinearLayout.VERTICAL);
        scrollView.addView(resultContainer);

        root.addView(scrollView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1
        ));

        setContentView(root);

        btnSearch.setOnClickListener(v -> searchComplaint());
    }

    private void searchComplaint() {
        String searchTitle = etSearch.getText().toString().trim();

        if (searchTitle.isEmpty()) {
            etSearch.setError("Please enter a complaint title.");
            return;
        }

        resultContainer.removeAllViews();

        SharedPreferences preferences = getSharedPreferences(
                "CivicFixComplaints", MODE_PRIVATE);

        String savedData = preferences.getString("complaints", "[]");

        try {
            JSONArray complaints = new JSONArray(savedData);
            boolean found = false;

            for (int i = complaints.length() - 1; i >= 0; i--) {
                JSONObject complaint = complaints.getJSONObject(i);

                String title = complaint.optString("title", "");

                if (title.equalsIgnoreCase(searchTitle)) {
                    found = true;

                    TextView details = new TextView(this);
                    details.setText(
                            "Complaint: " + title
                                    + "\n\nDescription: "
                                    + complaint.optString("description", "")
                                    + "\n\nCategory: "
                                    + complaint.optString("category", "")
                                    + "\n\nLocation: "
                                    + complaint.optString("location", "")
                    );
                    details.setTextSize(17);
                    details.setTextColor(Color.rgb(23, 43, 77));
                    details.setPadding(0, 20, 0, 16);
                    resultContainer.addView(details);

                    TextView status = new TextView(this);
                    status.setText(
                            "Status: " +
                                    complaint.optString("status", "Submitted")
                    );
                    status.setTextSize(19);
                    status.setTypeface(null, Typeface.BOLD);
                    status.setTextColor(Color.rgb(22, 128, 61));
                    resultContainer.addView(status);

                    break;
                }
            }

            if (!found) {
                Toast.makeText(
                        this,
                        "Complaint not found. Check the title.",
                        Toast.LENGTH_LONG
                ).show();
            }

        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "Unable to load complaint details.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }
}
