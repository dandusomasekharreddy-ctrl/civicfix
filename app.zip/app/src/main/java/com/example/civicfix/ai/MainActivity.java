package com.example.civicfix.ai;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View rootView = findViewById(R.id.mainRoot);

        if (rootView != null) {
            ViewCompat.setOnApplyWindowInsetsListener(rootView, (view, insets) -> {
                int top = insets.getInsets(
                        WindowInsetsCompat.Type.statusBars()
                ).top;

                int bottom = insets.getInsets(
                        WindowInsetsCompat.Type.navigationBars()
                ).bottom;

                view.setPadding(
                        view.getPaddingLeft(),
                        top,
                        view.getPaddingRight(),
                        bottom
                );

                return insets;
            });
        }

        Button btnReport = findViewById(R.id.btnReport);
        Button complaintsButton = findViewById(R.id.btnComplaints);
        Button trackButton = findViewById(R.id.btnTrack);

        btnReport.setOnClickListener(v -> {
            Intent intent = new Intent(
                    MainActivity.this,
                    ReportComplaintActivity.class
            );
            startActivity(intent);
        });

        complaintsButton.setOnClickListener(v -> {
            Intent intent = new Intent(
                    MainActivity.this,
                    MyComplaintsActivity.class
            );
            startActivity(intent);
        });

        trackButton.setOnClickListener(v -> {
            Intent intent = new Intent(
                    MainActivity.this,
                    TrackComplaintActivity.class
            );
            startActivity(intent);
        });
    }
}